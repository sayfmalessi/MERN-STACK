import './App.css'
import Formvalidation from './component/Formvalidation'

function App() {
  

  return (
    <>
      <Formvalidation/>
    </>
  )
}

export default App
