import React from 'react'
import { useState } from 'react';

function Formvalidation() {
    const [Firstname, setFirstname] = useState("");
    const [FirstnameError, setFirstnameError] = useState("");
    const [Lastname, setLastname] = useState("");
    const [LastnameError, setLastnameError] = useState("");
    const [email, setemail] = useState("");
    const [emailError, setemailError] = useState("");
    const [password, setpassword] = useState("");
    const [passwordError, setpasswordError] = useState("");
    
    const handleFirstname = (e) => {
        setFirstname(e.target.value);
        if(e.target.value.length < 1) {
            setFirstnameError("");
        } else if(e.target.value.length < 3) {
            setFirstnameError("Firstname must be 3 characters or longer!");
        } else {
            setFirstnameError("");
        }
    }

    const handleLastname = (e) => {
        setLastname(e.target.value);
            if(e.target.value.length < 1) {
            setemailError("");
            }
            else if(e.target.value.length < 3) {
            setLastnameError("Lastname must be 3 characters or longer!");
        } else {
            setLastnameError("");
        }
    }
    const handleemail= (e) => {
        setemail(e.target.value);
        if(e.target.value.length < 1) {
            setemailError("");
        } else if(e.target.value.length < 3) {
            setemailError("email must be 3 characters or longer!");
        } else {
            setemailError("");
        }
    }
    const handlepassword= (e) => {
        setpassword(e.target.value);
        if(e.target.value.length < 1) {
            setpasswordError("");
        } else if(e.target.value.length < 3) {
            setpasswordError("password must be 3 characters or longer!");
        } else {
            setpasswordError("");
        }
    }
    
    {/* rest of component removed for brevity */}
    
    return (
        <form onSubmit={ (e) => e.preventDefault() }>
            <div>
                <label>Firstname: </label>
                <input type="text" onChange={ handleFirstname } />
                {
                    FirstnameError ?
                    <p style={{color:'red'}}>{ FirstnameError }</p> :
                    ''
                }
            </div>
            <div>
                <label>Lastname: </label>
                <input type="text" onChange={ handleLastname } />
                {
                    LastnameError ?
                    <p style={{color:'red'}}>{ LastnameError }</p> :
                    ''
                }
            </div>
            <div>
                <label>email: </label>
                <input type="text" onChange={ handleemail } />
                {
                    emailError ?
                    <p style={{color:'red'}}>{ emailError }</p> :
                    ''
                }
            </div>
            <div>
                <label>password: </label>
                <input type="password" onChange={ handlepassword } />
                {
                    passwordError ?
                    <p style={{color:'red'}}>{ passwordError }</p> :
                    ''
                }
            </div>
            <input type="submit" value="Create Movie" />
        </form>
    );



}

export default Formvalidation